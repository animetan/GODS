"""
nextcord.types
~~~~~~~~~~~~~~

Typings for the Discord API

:copyright: (c) 2015-present Rapptz
:copyright: (c) 2021-present tag-epic
:license: MIT, see LICENSE for more details.

"""
