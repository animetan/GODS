# ipc

Interprocess communication via standard streams (stdin, stdout, stderr).

## Installation

```
$ pip install ipc
```
